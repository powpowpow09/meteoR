
#' @import assertive
#' @export
netatmo_files_pattern <- function(pattern = NULL) {
  assertive::assert_is_not_null(pattern)
  assertive::assert_is_list(pattern)

  pattern <- toupper(pattern)

  if (any(pattern == "OUTDOOR")) {
    pattern <- pattern[-which(pattern == "OUTDOOR")]
    pattern <- append(pattern, list("PLUVIOMÈTRE", "EXTÉRIEUR", "ANÉMOMÈTRE"))
  }

  pattern
}


#' @import lubridate
#' @export
netatmo_files_datetime <- function(data_frame = NULL) {
  assertive::assert_is_not_null(data_frame)
  assertive::assert_is_data.frame(data_frame)

  data_frame$date <- lubridate::date(data_frame$datetime)
  data_frame$minute <- as.integer(lubridate::minute(data_frame$datetime))
  data_frame$hour <- as.integer(lubridate::hour(data_frame$datetime))
  data_frame$day <- as.integer(lubridate::day(data_frame$datetime))
  data_frame$week <- as.integer(lubridate::isoweek(data_frame$datetime))
  data_frame$month <- as.integer(lubridate::month(data_frame$datetime))
  data_frame$month_abbr <- lubridate::month(data_frame$datetime, label = TRUE, abbr = TRUE)
  data_frame$month_abbr <- gsub("\\.", "", data_frame$month_abbr, fixed = TRUE)
  data_frame$year <- as.integer(lubridate::year(data_frame$datetime))

  data_frame
}

