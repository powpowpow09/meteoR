#' netatmo_indoor object R6
#'
#' @param data
#'
#' @import assertive
#' @import R6
#'
#' @export
#'
#' @examples
#' dir_csv <- "f:/r/netatmo/csv"
#' file_lst <- netatmo_file_to_load(dir_csv, pattern = list("indoor", "outdoor"))
#' db_lst <- load_csv(file_lst)
#' boo <- netatmo_indoor_obj$new(db_lst$db_netatmo_indoor)
netatmo_indoor_obj <- R6::R6Class(
  "netatmo_indoor",
  public = list(
    data = NULL,

    initialize = function(data) {
      self$data <- data
      self$valid()
    },

    valid = function(...) {
      assertive::assert_is_not_null(data)

      assertive::assert_is_data.frame(self$data)

      assertive::assert_is_double(self$data$id)
      assertive::assert_is_posixct(self$data$datetime)
      assertive::assert_is_date(self$data$date)
      assertive::assert_is_integer(self$data$minute)
      assertive::assert_is_integer(self$data$hour)
      assertive::assert_is_integer(self$data$day)
      assertive::assert_is_integer(self$data$week)
      assertive::assert_is_integer(self$data$month)
      assertive::assert_is_integer(self$data$year)
      assertive::assert_is_double(self$data$temperature)
      assertive::assert_is_double(self$data$humidity)
      assertive::assert_is_double(self$data$c02)
      assertive::assert_is_double(self$data$noise)
      assertive::assert_is_double(self$data$pressure)
    }
  )
)


#' summary of netatmo_indoor object
#'
#' @param obj
#' @param ...
#'
#' @import assertive
#' @import dplyr
#' @import tidyr
#'
#' @return
#' @export
#'
#' @examples
summary.netatmo_indoor <- function(obj = NULL, ...) {
  assertive::assert_is_not_null(obj)

  boo <-
    dplyr::as_data_frame(obj$data) %>%
    dplyr::select(year, month_abbr, temperature, humidity, c02, noise, pressure) %>%
    tidyr::gather(measure, value, -year, -month_abbr) %>%
    group_by(year, month_abbr, measure) %>%
    dplyr::summarise_all(funs(
      min = round(min(., na.rm = TRUE), 1),
      max = round(max(., na.rm = TRUE), 1),
      Q25 = round(quantile(., probs = 0.25, na.rm = TRUE), 1),
      Q75 = round(quantile(., probs = 0.75, na.rm = TRUE), 1),
      avg = round(mean(., na.rm = TRUE), 1),
      med = round(median(., na.rm = TRUE), 1),
      sum = round(sum(., na.rm = TRUE), 1),
      range = round(max - min, 1),
      n_obs = n()
    )) %>%
    dplyr::arrange(year, month_abbr, measure)

  if (requireNamespace("knitr", quietly = TRUE)) {
    knitr::kable(head(boo, ...))
  } else {
    boo %>% print(...)
  }
}



#' convert a netatmo_indoor object in tibble
#'
#' @param obj
#' @param ...
#'
#' @import assertive
#' @import dplyr
#' @import tibble
#'
#' @return
#' @export
#'
#' @examples
as_tibble.netatmo_indoor  <- function(obj = NULL, ...) {
  assertive::assert_is_not_null(obj)

  boo <- dplyr::as_data_frame(obj$data) %>% dplyr::arrange(year, month, day)

  boo
}

